<?php
include("connection.php");
if(isset($_POST["id"]))
{
   $id=$_POST["id"];
   $sql=mysqli_query($conn," DELETE FROM users WHERE id ='$id'")or die(mysqli_error($conn));  
   if($sql)
   {
     header('location:index.php');
   }
   else
   {
	   echo"Not Working";
   }

}
?>