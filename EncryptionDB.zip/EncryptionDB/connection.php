<?php
	$conn=mysqli_connect("localhost","root","","users");
	//databse should contain VARBINARY (100) as the coloumn type and lenght.
	//ID should contain INT | Primarykey | Autoincrement 
	//Password should contain Varchar (100)
?>
