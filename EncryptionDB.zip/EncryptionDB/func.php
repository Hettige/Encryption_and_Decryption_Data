	<?php
	$key=md5('SriLanka');//can have any word as a KEY
	$salt=md5('SriLanka'); //can have any word as a SALT
	
	function encrypt($String,$key)
	{
		$String=rtrim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256,$key,$String,MCRYPT_MODE_ECB)));
		return $String;
	}
	function decrypt($String,$key)
	{
		$String=rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256,$key,base64_decode($String),MCRYPT_MODE_ECB));
		return $String;
	}
	function hashword($String,$salt)
	{
		$String = crypt($String, '$1$' . $salt . '$');
		return $String;
	}	
?>