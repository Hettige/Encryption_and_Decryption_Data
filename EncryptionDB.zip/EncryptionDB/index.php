<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Encryption and decryption</title>
<style>
	#customers 
	{
	  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}

	#customers td, #customers th 
	{
	  border: 1px solid #ddd;
	  padding: 8px;
	}

	#customers tr:nth-child(even)
	{
		background-color: #f2f2f2;
	}

	#customers tr:hover 
	{
		background-color: #ddd;
	}

	#customers th 
	{
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #1753E0;
	  color: white;
	}
</style>
</head>
<body>
	<h2>Fill the Form</h2>	
	<form name="secure" method="post" action="insert.php">
		<table>
			<tr>
				<td>Name: </td>
				<td><input type="text" name="nm" id="nm" required></td>
			</tr>
			<tr>
				<td>Address: </td>
				<td><input type="text" name="add" id="add" required></td>
			</tr>
			<tr>
				<td>ZIP: </td>
				<td><input type="text" name="zip" id="zip" required></td>
			</tr>
			<tr>
				<td>Email: </td>
				<td><input type="email" name="eml" id="rml" required></td>
			</tr>
			<tr>
				<td>Password: </td>
				<td><input type="password" name="pw" id="pw" required></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btn" id="btn" value="Submit"> &nbsp; <input type="reset" name="btn2" id="btn2" value="Clear"></td>	
			</tr>
		</table>
	</form>	
	<h3>Raw data from Database</h3>	
	<table id="customers">
		<thead>
			<tr>
				<th align="center">ID</th>
				<th align="center">Name</th>
				<th align="center">Address</th>
				<th align="center">ZIP</th>
				<th align="center">Email</th>
				<th align="center">Password</th>
				<th align="center">Delete</th>
			</tr>
		</thead>
		<tbody>
			<?php
				include("func.php");//importing the decrypting function
			
				$db_host = 'localhost'; // Server Name
				$db_user = 'root'; // Username
				$db_pass = ''; // Password
				$db_name = 'users'; // Database Name

				$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
				if (!$conn) 
				{
					die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
				}
				$sql = 'SELECT * FROM users';
				$query = mysqli_query($conn, $sql);

				if (!$query) 
				{
					die ('SQL Error: ' . mysqli_error($conn));
				}
			?>			
			<?php 
			//password has not decrypting due to hashword
			while ($row = mysqli_fetch_array($query))
			{
				echo 
					'<tr>
					<td>'.$row['id'].'</td>
					<td>' .decrypt($row['name'],$key).'</td>
					<td>' .decrypt($row['address'],$key).'</td>
					<td>' .decrypt($row['zip'],$key).'</td>
					<td>' .decrypt($row['email'],$key).'</td>
					<td>' .$row['password'].'</td>	
					<td>
						<form name="delete_form" action="delete.php" method="POST" >
							<input name="id" type="hidden" value='.$row['id'].'>
							<input  type="submit" value="Delete">
						</form>
					</td>
					
					</tr>';
			}
			?>
		</tbody>
	</table>
	<p>Created by : M.H. Hettige</p>
</body>
</html>