<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php	
	include("func.php");//importing the encrpting function
	include("connection.php");
	$NM=$_REQUEST["nm"];
	$addrss=$_REQUEST["add"];
	$zip=$_REQUEST["zip"];
	$mail=$_REQUEST["eml"];
	$pw=$_REQUEST["pw"];
	
	$serverName = "localhost";
	$userName = "root";
	$password = "";
	$dbName = "users";
	
	$conn = new mysqli($serverName,$userName,$password,$dbName);
	function protect($String)
	{
		$String=mysql_real_escape_string(trim(strip_tags(addslashes($String))));
		return($String);
	};
	$pw=hashword($pw,$salt);
	
	$sql = "insert into users (name,address,zip,email,password) values('".encrypt($NM,$key)."','".encrypt($addrss,$key)."','".encrypt($zip,$key)."','".encrypt($mail,$key)."','$pw')";

	if(mysqli_query($conn, $sql))
	{
		echo "New record created successfully";
		header('Location:index.php');
	}
	else 
	{
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	?>
</body>
</html>