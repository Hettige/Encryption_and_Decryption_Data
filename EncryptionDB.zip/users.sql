-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2019 at 08:40 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varbinary(100) NOT NULL,
  `address` varbinary(100) NOT NULL,
  `zip` varbinary(100) NOT NULL,
  `email` varbinary(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `address`, `zip`, `email`, `password`) VALUES
(13, 'ngx6Hm5gqA1vlGtPJNeBOQvYXs8pMZQwoDrn1GRfOpo=', 'Yg4hTmQffxdv3pIcGBe80u1LZMkWjjXNLYY5NLjr5sw=', 'uQXWtKfepnM9PVtJk+kYkpMra2FC89L+ousJOK1nqOA=', '+mtfnHFHmoNk2ymdHM0TSB84H61FcuFVLBnpwV18hmY=', '$1$b0595cb1$oAWO.oOzYkWIk5XjtxCdS0'),
(14, 'IQrclPplswf6bCpiSObzRQ1mu/sm8FqeEWG3o95z0aU=', 'Yg4hTmQffxdv3pIcGBe80u1LZMkWjjXNLYY5NLjr5sw=', 'uQXWtKfepnM9PVtJk+kYkpMra2FC89L+ousJOK1nqOA=', 'UAa+phoQN7e/STmKGwq2tssRRtO/CXWbF+m8bYMkViw=', '$1$b0595cb1$Bme74RreWVIh75kQ4FdzN1'),
(15, 'XVIzN6/D4kYT3xTUMH4dJSfmnHtwhNZRmVxs4xaFxCM=', 'PX0ZRlY2xOkNW/S82X++upP4r5swL0fcd3FD0py4o1I=', '7/WZKe4xAVV22ILhNKGwnTT9qWPQLn5ZFCLRKfYRNKM=', 'gbVxs0eCkC7GoDDksCyvinSSlzgzbd+JYNwCC0in8ws=', '$1$b0595cb1$hMSAEbhfX2DFxCtJ8dzdK1'),
(16, '12EAH/KzDP5Qh0ZH1PfIRbsx6lu5XtbxjcFX1aLF+Dc=', 'ahlhcrwSC/RstYRVIALuC1jn+X/rkXqN2Yk9+PPfIfc=', 'qz3S6XIm757kPwNbKxgAYrhU7BPerMWfe9oijkLV9GA=', 'sSV/2KjxnjUTgRstHI74/xrZVivx44n8nnU4mKzSooQ=', '$1$b0595cb1$s.LHYmfg5JCw/J5g/gKXK.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
